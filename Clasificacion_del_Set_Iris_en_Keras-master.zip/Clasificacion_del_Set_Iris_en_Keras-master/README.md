# Clasificación del set Iris en Keras

Set de datos y código fuente donde con la implementación de la Regresión Multiclase aplicada al set Iris, como se explica en [este video tutorial](https://youtu.be/MuPh3h7hwb4)

Para la explicación paso a paso visita el [artículo en Codificando Bits](https://codificandobits.com/deep-learning/2018/08/27/clasificacion-del-set-iris-en-keras.html).
